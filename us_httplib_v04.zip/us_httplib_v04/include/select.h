//
//File : 	select.h
//Function: head file
//author: 	menden
//date:		16OCT2021
//version:	V0.1
//

#ifndef __SELECT_H
#define __SELECT_H

int string_select(char* str_in);
void string_gen(char* str_in);

#endif
