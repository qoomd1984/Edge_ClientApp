/***************************************************************
 * Name:      ClientApps_alphaApp.h
 * Purpose:   Defines Application Class
 * Author:    wzqiu (wzqiu@foxmail.com)
 * Created:   2021-12-07
 * Copyright: wzqiu (jiefengtech.com.cn)
 * License:
 **************************************************************/

#ifndef CLIENTAPPS_ALPHAAPP_H
#define CLIENTAPPS_ALPHAAPP_H

#include <wx/app.h>



class ClientApps_alphaApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // CLIENTAPPS_ALPHAAPP_H
