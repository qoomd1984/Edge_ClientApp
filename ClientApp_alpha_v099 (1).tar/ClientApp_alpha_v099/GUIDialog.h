///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Feb 17 2007)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#ifndef __GUIDialog__
#define __GUIDialog__

// Define WX_GCH in order to support precompiled headers with GCC compiler.
// You have to create the header "wx_pch.h" and include all files needed
// for compile your gui inside it.
// Then, compile it and place the file "wx_pch.h.gch" into the same
// directory that "wx_pch.h".
#ifdef WX_GCH
#include <wx_pch.h>
#else
#include <wx/wx.h>
#endif

#include <wx/button.h>
//#include <wx/statline.h>
#include <wx/textctrl.h>
#include <wx/choice.h>
#include <wx/datetime.h>
#include <wx/timer.h>
#include <wx/longlong.h>
//#include <wx/time.h>

#include "ctb-0.16/ctb.h"



///////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
/// Class GUIDialog
///////////////////////////////////////////////////////////////////////////////
class GUIDialog : public wxDialog 
{
    DECLARE_EVENT_TABLE()
    private:
        
        // Private event handlers
        void _wxFB_OnClose( wxCloseEvent& event ){ OnClose( event ); }
        void _wxFB_OnAbout( wxCommandEvent& event ){ OnAbout( event ); }
        void _wxFB_OnQuit( wxCommandEvent& event ){ OnQuit( event ); }
        void _wxFB_OnClick1( wxCommandEvent& event ){ OnClick1( event ); }
		void _wxFB_OnClick2( wxCommandEvent& event ){ OnClick2( event ); }
		void _wxFB_OnClick3( wxCommandEvent& event ){ OnClick3( event ); }
		void _wxFB_OnClick4( wxCommandEvent& event ){ OnClick4( event ); }
		void _wxFB_OnClick5( wxCommandEvent& event ){ OnClick5( event ); }
		void _wxFB_OnChoice1( wxCommandEvent& event ){ OnChoice1( event ); }
		void _wxFB_OnChoice2( wxCommandEvent& event ){ OnChoice2( event ); }
		void _wxFB_OnTextCtrl1(wxCommandEvent& event){ OnTextCtrl1( event ); }
		void _wxFB_OnTextCtrl2(wxCommandEvent& event){ OnTextCtrl2( event ); }
		void _wxFB_OnTextCtrl3(wxCommandEvent& event){ OnTextCtrl3( event ); }
		void _wxFB_OnTimer(wxTimerEvent& event){ OnTimer( event ); }
    
    protected:
        enum
        {
            idBtnAbout = 1000,
            idBtnQuit,
			idStaticText1,
			idStaticText2,
			idStaticText3,
			idStaticText4,
			idStaticText5,
			idDateTime,
			ID_Choice1,
			ID_Choice2,
			idBtnClick1,
			idBtnClick2,
			idBtnClick3,
			idBtnClick4,
			idBtnClick5,
			idTextCtrl1,
			idTextCtrl2,
			idTextCtrl3,
			idTimer
        };
		
		//galebl Var
		size_t label_sta1 = 1000;
		size_t label_sta2 = 1000;
		size_t label_sta3 = 1000;
		size_t label_sta4 = 1000;
		size_t label_sta5 = 1000;
		int num = 0;
		
		//ctb
		int baudrate = 115200;
		std::string devname = "/dev/ttyACM0";
		//std::string devname = "/dev/ttyS2";
		std::string eos = "\r\n";
		std:: string protocol = "8N1";
		int timeout = 100;
		bool showAvailablePorts = false;
		bool uart_status = false;
		ctb::SerialPort* serialPort = new ctb::SerialPort();
		std::string str_get;
		
		//API class decl
        wxStaticText* m_staticText1;
		wxStaticText* m_staticText2;
		wxStaticText* m_staticText3;
		wxStaticText* m_staticText4;
		wxStaticText* m_staticText5;
		
		wxDateTime* m_dateTime;
		
		wxButton* BtnAbout;
		wxButton* BtnQuit;
		wxButton* BtnClick1;
		wxButton* BtnClick2;
		wxButton* BtnClick3;
		wxButton* BtnClick4;
		wxButton* BtnClick5;
		
		wxChoice* Choice1;
		wxChoice* Choice2;
		
		wxTextCtrl* m_TextCtrl1;
		wxTextCtrl* m_TextCtrl2;
		wxTextCtrl* m_TextCtrl3;
		wxTimer* m_Timer;

        // Virtual event handlers, overide them in your derived class
        virtual void OnClose( wxCloseEvent& event ){ event.Skip(); }
        virtual void OnAbout( wxCommandEvent& event ){ event.Skip(); }
        virtual void OnQuit( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnClick1( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnClick2( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnClick3( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnClick4( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnClick5( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnChoice1( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnChoice2( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnTextCtrl1( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnTextCtrl2( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnTextCtrl3( wxCommandEvent& event ){ event.Skip(); }
		virtual void OnTimer( wxTimerEvent& event ){ event.Skip(); }
    public:
        GUIDialog( wxWindow* parent, int id = wxID_ANY, wxString title = wxT("wxWidgets Application Template"), wxPoint pos = wxDefaultPosition, wxSize size = wxDefaultSize, int style = wxDEFAULT_DIALOG_STYLE );
};

#endif //__GUIDialog__
