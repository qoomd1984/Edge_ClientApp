/***************************************************************
 * Name:      ClientApps_alphaMain.h
 * Purpose:   Defines Application Frame
 * Author:    wzqiu (wzqiu@foxmail.com)
 * Created:   2021-12-07
 * Copyright: wzqiu (jiefengtech.com.cn)
 * License:
 **************************************************************/

#ifndef CLIENTAPPS_ALPHAMAIN_H
#define CLIENTAPPS_ALPHAMAIN_H



#include "ClientApps_alphaApp.h"
#include "GUIDialog.h"

class ClientApps_alphaDialog: public GUIDialog
{
    public:
        ClientApps_alphaDialog(wxDialog *dlg);
        ~ClientApps_alphaDialog();
    private:
        virtual void OnClose(wxCloseEvent& event);
		
        virtual void OnQuit(wxCommandEvent& event);
        virtual void OnAbout(wxCommandEvent& event);
		virtual void OnClick1(wxCommandEvent& event);
		virtual void OnClick2(wxCommandEvent& event);
		virtual void OnClick3(wxCommandEvent& event);
		virtual void OnClick4(wxCommandEvent& event);
		virtual void OnClick5(wxCommandEvent& event);
		virtual void OnChoice1(wxCommandEvent& event);
		virtual void OnChoice2(wxCommandEvent& event);
		virtual void OnTextCtrl1(wxCommandEvent& event);
		virtual void OnTextCtrl2(wxCommandEvent& event);
		virtual void OnTextCtrl3(wxCommandEvent& event);
		virtual void OnTimer(wxTimerEvent& event);
};
#endif // CLIENTAPPS_ALPHAMAIN_H
