/***************************************************************
 * Name:      ClientApps_alphaMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    wzqiu (wzqiu@foxmail.com)
 * Created:   2021-12-07
 * Copyright: wzqiu (jiefengtech.com.cn)
 * License:
 **************************************************************/

#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#include "ClientApps_alphaMain.h"

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__WXMAC__)
        wxbuild << _T("-Mac");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}



ClientApps_alphaDialog::ClientApps_alphaDialog(wxDialog *dlg)
    : GUIDialog(dlg)
{
}

ClientApps_alphaDialog::~ClientApps_alphaDialog()
{
}

void ClientApps_alphaDialog::OnClose(wxCloseEvent &event)
{
    Destroy();
}

void ClientApps_alphaDialog::OnQuit(wxCommandEvent &event)
{
    Destroy();
}

void ClientApps_alphaDialog::OnAbout(wxCommandEvent &event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to PTJieFeng."));
}

void ClientApps_alphaDialog::OnClick1(wxCommandEvent &event)
{
    //set text
	wxString str_btnClick1;
	
	str_btnClick1 = BtnClick1->GetLabel();
	
	if(label_sta1 == 1000)
	{
		label_sta1 = 1001;
		BtnClick1->SetLabel("&OPEN");
		
		if( serialPort->Open( devname.c_str(), baudrate, 
					protocol.c_str(),
					ctb::SerialPort::NoFlowControl ) >= 0 ) {
			uart_status = true;
			m_TextCtrl3->SetValue("COM Running!!!");			
		}
		
		if( ! uart_status ) {
			m_TextCtrl3->SetValue("COM ERROR!!!");
		}
		//end of uart init
	}
	else {
		label_sta1 = 1000;
		BtnClick1->SetLabel("&CLOSE");
	
	}
	//BtnClick1->SetLabel("&ON");
	
}

void ClientApps_alphaDialog::OnClick2(wxCommandEvent &event)
{
    //set text
	wxString str_btnClick2;
	
	str_btnClick2 = BtnClick2->GetLabel();
	
	if(label_sta2 == 1000)
	{
		label_sta2 = 1001;
		BtnClick2->SetLabel("&Off-Line");
	
	}
	else {
		label_sta2 = 1000;
		BtnClick2->SetLabel("&On-Line");
		
	}
	//BtnClick1->SetLabel("&ON");
}

void ClientApps_alphaDialog::OnClick3(wxCommandEvent &event)
{
	    //set text
	wxString str_btnClick3;
	
	str_btnClick3 = BtnClick3->GetLabel();
	
	if(label_sta3 == 1000)
	{
		label_sta3 = 1001;
		BtnClick3->SetLabel("&OFF");
	
	}
	else {
		label_sta3 = 1000;
		BtnClick3->SetLabel("&ON");
		
	}
	//BtnClick1->SetLabel("&ON");
}

void ClientApps_alphaDialog::OnClick4(wxCommandEvent &event)
{
		    //set text
	wxString str_btnClick4;
	
	str_btnClick4 = BtnClick4->GetLabel();
	
	if(label_sta4 == 1000)
	{
		label_sta4 = 1001;
		BtnClick4->SetLabel("&OFF");
	
	}
	else {
		label_sta4 = 1000;
		BtnClick4->SetLabel("&ON");
		
	}
	//BtnClick1->SetLabel("&ON");
}

void ClientApps_alphaDialog::OnClick5(wxCommandEvent &event)
{
	//set text
	wxString str_btnClick5;
	
	str_btnClick5 = BtnClick5->GetLabel();
	
	if(label_sta5 == 1000)
	{
		label_sta5 = 1001;
		BtnClick5->SetLabel("&OFF");
	
	}
	else {
		label_sta5 = 1000;
		BtnClick5->SetLabel("&ON");
		
	}
	//BtnClick1->SetLabel("&ON");
}

void ClientApps_alphaDialog::OnTextCtrl1(wxCommandEvent &event)
{
}

void ClientApps_alphaDialog::OnTextCtrl2(wxCommandEvent &event)
{
}

void ClientApps_alphaDialog::OnTextCtrl3(wxCommandEvent &event)
{
}

void ClientApps_alphaDialog::OnChoice1(wxCommandEvent &event)
{
}

void ClientApps_alphaDialog::OnChoice2(wxCommandEvent &event)
{
}
void ClientApps_alphaDialog::OnTimer(wxTimerEvent &event)
{
	//set text
//	wxTimeSpan time_value_t;
//	wxLongLong str_dateTime_t;
//	str_dateTime_t = time_value_t.GetMilliseconds();
//	str_time_value = str_dateTime_t.ToString();
	
//	num++;
//	wxString str_num = wxString::Format(wxT("%i"), num);
	
	char str_buf[255]; //fifo buffer size is 512		
	for(int i=0; i<255; i++) {
		str_buf[i] = '\0';
	}
	
	int readed = 0;
	readed = serialPort->Readv( str_buf, 
						sizeof(str_buf) - 1, 
						timeout);
	// something received?
	if( readed > 0 ) {
		str_get = str_buf;
	}
	
	m_TextCtrl3->SetValue(str_get);
}
//end of AlphaMain.cpp