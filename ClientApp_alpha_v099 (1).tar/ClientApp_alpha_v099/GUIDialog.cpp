///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Feb 17 2007)
// http://www.wxformbuilder.org/
//
// PLEASE DO "NOT" EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif //WX_PRECOMP

#include "GUIDialog.h"

///////////////////////////////////////////////////////////////////////////
BEGIN_EVENT_TABLE( GUIDialog, wxDialog )
    EVT_CLOSE( GUIDialog::_wxFB_OnClose )
    EVT_BUTTON( idBtnAbout, GUIDialog::_wxFB_OnAbout )
    EVT_BUTTON( idBtnQuit, GUIDialog::_wxFB_OnQuit )
	EVT_BUTTON( idBtnClick1, GUIDialog::_wxFB_OnClick1 )
	EVT_BUTTON( idBtnClick2, GUIDialog::_wxFB_OnClick2 )
	EVT_BUTTON( idBtnClick3, GUIDialog::_wxFB_OnClick3 )
	EVT_BUTTON( idBtnClick4, GUIDialog::_wxFB_OnClick4 )
	EVT_BUTTON( idBtnClick5, GUIDialog::_wxFB_OnClick5 )
	EVT_CHOICE( ID_Choice1, GUIDialog::_wxFB_OnChoice1 )
	EVT_CHOICE( ID_Choice2, GUIDialog::_wxFB_OnChoice2 )
	EVT_TEXT( idTextCtrl1, GUIDialog::_wxFB_OnTextCtrl1 )
	EVT_TEXT( idTextCtrl2, GUIDialog::_wxFB_OnTextCtrl2 )
	EVT_TEXT( idTextCtrl3, GUIDialog::_wxFB_OnTextCtrl3 )
	EVT_TIMER ( idTimer, GUIDialog::_wxFB_OnTimer )
END_EVENT_TABLE()

GUIDialog::GUIDialog( wxWindow* parent, int id, wxString title, wxPoint pos, wxSize size, int style ) : wxDialog( parent, id, title, pos, size, style )
{
    this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	
	m_Timer = new wxTimer(this, idTimer);
	m_Timer->Start(2000, wxTIMER_CONTINUOUS);    // 100ms interval
    
	//BOX1
    wxBoxSizer* bSizer1;
    bSizer1 = new wxBoxSizer( wxHORIZONTAL );
	
	wxBoxSizer* bSizer2;
	bSizer2 = new wxBoxSizer( wxVERTICAL );
	
	//Choice1-COM BOX2
	Choice1 = new wxChoice(this, ID_Choice1, wxDefaultPosition, wxDefaultSize, 0, 0, 0, wxDefaultValidator, _T("COM1"));
	Choice1->Append(wxT("COM1"));
	Choice1->Append(wxT("COM2"));
	Choice1->Append(wxT("COM3"));
	Choice1->Append(wxT("COM4"));
	Choice1->Append(wxT("COM5"));
	Choice1->Append(wxT("COM6"));
	bSizer2->Add(Choice1, 1, wxALL|wxEXPAND, 5);
	
	//static Text-UART status
	m_staticText1 = new wxStaticText( this, idStaticText1, wxT("UART Statu"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText1->SetFont( wxFont( 20, 74, 90, 90, false, wxT("Arial") ) );
    bSizer2->Add( m_staticText1, 1, wxALL|wxEXPAND, 5 );//BOX2
	
	m_TextCtrl1= new wxTextCtrl(this, idTextCtrl1, wxT("NAME"), wxDefaultPosition, wxDefaultSize, 0 );
	m_TextCtrl1->SetFont( wxFont( 20, 74, 90, 90, false, wxT("Arial") ) );
	bSizer2->Add( m_TextCtrl1, 1, wxALL|wxEXPAND, 5 );	//BOX2
	
	//static Text-Login status
	m_staticText2 = new wxStaticText( this, idStaticText2, wxT("Login Statu"), wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText2->SetFont( wxFont( 20, 74, 90, 90, false, wxT("Arial") ) );
    bSizer2->Add( m_staticText2, 1, wxALL|wxEXPAND, 5 );//BOX2
	
	bSizer1->Add( bSizer2, 1, wxEXPAND, 5 );	//box2 add into box1
	
	//BOX3
	wxBoxSizer* bSizer3;
    bSizer3 = new wxBoxSizer( wxVERTICAL );
	
	//Choice2-BPS
	Choice2 = new wxChoice(this, ID_Choice2, wxDefaultPosition, wxDefaultSize, 0, 0, 0, wxDefaultValidator, _T("9600"));
	Choice2->Append(wxT("9600"));
	Choice2->Append(wxT("38400"));
	Choice2->Append(wxT("115200"));	
	bSizer3->Add(Choice2, 1, wxALL|wxEXPAND, 5);
	
	//CLose button
    BtnClick1 = new wxButton( this, idBtnClick1, wxT("&CLOSE"), wxDefaultPosition, wxDefaultSize, 0 );
    bSizer3->Add(  BtnClick1, 1, wxALL|wxEXPAND, 5 );	//BOX3 line:0 size:5
	
	//password textctl
	m_TextCtrl2= new wxTextCtrl(this, idTextCtrl2, wxT("PassWord"), wxDefaultPosition, wxDefaultSize, 0 );
	m_TextCtrl2->SetFont( wxFont( 20, 74, 90, 90, false, wxT("Arial") ) );
	bSizer3->Add( m_TextCtrl2, 1, wxALL|wxEXPAND, 5 );	//BOX2
	
	//Login button
    BtnClick2 = new wxButton( this, idBtnClick2, wxT("&Off-Line"), wxDefaultPosition, wxDefaultSize, 0 );
    bSizer3->Add(  BtnClick2, 1, wxALL|wxEXPAND, 5 );	//BOX3 line:0 size:5
	
	bSizer1->Add( bSizer3, 1, wxEXPAND, 5 );	//box2 add into box1
	
	//BOX4
	wxBoxSizer* bSizer4;
    bSizer4 = new wxBoxSizer( wxVERTICAL );
	
	//static Text3
	m_staticText3 = new wxStaticText( this, idStaticText3, wxT("DoorKeeper"), wxDefaultPosition, wxDefaultSize, 0 );
    m_staticText3->SetFont( wxFont( 20, 74, 90, 90, false, wxT("Arial") ) );
	bSizer4->Add( m_staticText3, 1, wxALL|wxEXPAND, 5 );//BOX2 line:1 size:5
	
	//static Text4
	m_staticText4 = new wxStaticText( this, idStaticText4, wxT("KittyTag"), wxDefaultPosition, wxDefaultSize, 0 );
    m_staticText4->SetFont( wxFont( 20, 74, 90, 90, false, wxT("Arial") ) );
    bSizer4->Add( m_staticText4, 1, wxALL|wxEXPAND, 5 );//BOX2 line:2 size:5
	
	//Text3
	m_TextCtrl3= new wxTextCtrl(this, idTextCtrl3, wxT("000000"), wxDefaultPosition, wxDefaultSize, 0 );
	m_TextCtrl3->SetFont( wxFont( 20, 74, 90, 90, false, wxT("Arial") ) );
	bSizer4->Add( m_TextCtrl3, 1, wxALL|wxEXPAND, 5 );	//BOX2
	
	//About
	BtnAbout = new wxButton( this, idBtnAbout, wxT("&About"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer4->Add( BtnAbout, 1, wxALL|wxEXPAND, 5 );	//BOX3 line:2 size:5
	
	bSizer1->Add( bSizer4, 1, wxEXPAND, 5 );	//box2 add into box1
	
    //BOX5
	wxBoxSizer* bSizer5;
    bSizer5 = new wxBoxSizer( wxVERTICAL );
	
	//new click button
    BtnClick3 = new wxButton( this, idBtnClick3, wxT("&OFF"), wxDefaultPosition, wxDefaultSize, 0 );
    bSizer5->Add(  BtnClick3, 1, wxALL|wxEXPAND, 5 );	//BOX3 line:0 size:5
	
	//new click button
    BtnClick4 = new wxButton( this, idBtnClick4, wxT("&OFF"), wxDefaultPosition, wxDefaultSize, 0 );
    bSizer5->Add(  BtnClick4, 1, wxALL|wxEXPAND, 5 );	//BOX3 line:0 size:5
	
	//new click button
    BtnClick5 = new wxButton( this, idBtnClick5, wxT("&OFF"), wxDefaultPosition, wxDefaultSize, 0 );
    bSizer5->Add(  BtnClick5, 1, wxALL|wxEXPAND, 5 );	//BOX3 line:0 size:5
	
	//Quit
	BtnQuit = new wxButton( this, idBtnQuit, wxT("&Quit"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer5->Add(  BtnQuit, 1, wxALL|wxEXPAND, 5 );	//BOX3 line:3 size:5
	
	bSizer1->Add( bSizer5, 1, wxEXPAND, 5 );
	
	this->SetSizer( bSizer1 );
	this->Layout();
	bSizer1->Fit( this );
	
	// And connect binding the event handlers.
	//Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&GUIDialog::OnQuit);
	m_TextCtrl1->Bind(wxEVT_BUTTON, &GUIDialog::OnClick1, this, idBtnClick1);
	m_TextCtrl2->Bind(wxEVT_BUTTON, &GUIDialog::OnClick2, this, idBtnClick2);
	m_TextCtrl3->Bind(wxEVT_TIMER, &GUIDialog::OnTimer, this, idTimer);
}
//end of GUIDialog.cpp