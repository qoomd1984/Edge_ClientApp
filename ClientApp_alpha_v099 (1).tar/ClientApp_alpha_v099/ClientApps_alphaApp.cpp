/***************************************************************
 * Name:      ClientApps_alphaApp.cpp
 * Purpose:   Code for Application Class
 * Author:    wzqiu (wzqiu@foxmail.com)
 * Created:   2021-12-07
 * Copyright: wzqiu (jiefengtech.com.cn)
 * License:
 **************************************************************/

#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#ifndef wxHAS_IMAGES_IN_RESOURCES
    #include "./sample.xpm"
#endif



#include "ClientApps_alphaApp.h"
#include "ClientApps_alphaMain.h"

IMPLEMENT_APP(ClientApps_alphaApp);

bool ClientApps_alphaApp::OnInit()
{
    
    ClientApps_alphaDialog* dlg = new ClientApps_alphaDialog(0L);
    dlg->SetIcon(wxICON(sample)); // To Set App Icon
    dlg->Show();
    return true;
}
